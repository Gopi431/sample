# Sensor skeleton plan (on-prem, no Azure)

**Status:** skeleton implemented. `DEFENDER_SOURCE=mock` uses fixtures. `DEFENDER_SOURCE=sensor` is a stub (no live HTTP until the client gives the API).

Keep **`defener-iot-middleware (Copy 2)`** as the Azure cloud project. Treat **`defender_iot_sensor`** as a **copy with Azure removed**, same pattern: mock now, live sensor later.

---

## What stays (same as Azure)

The pipeline does not care about Entra or Resource Graph:

**HTTP sync → fetch → map → upsert Postgres → UI list (limit/offset)**

Keep:

- routes / controller / orchestrator / repositories / models / sync-run
- `DEFENDER_SOURCE` switch (`mock` vs live)
- one mapper that outputs the **same `assets` columns**

Only **login, fetch, and raw JSON shape** change.

---

## What to remove (Azure-only)

| Remove | Why |
|--------|-----|
| `@azure/identity`, `@azure/arm-resourcegraph` | Cloud SDK |
| `resourceGraphService.js` | Resource Graph + `$skipToken` |
| `azure.js` tenant/client/secret/subscription | Entra login |
| Azure env vars | Not used on-prem |
| Azure markdown notes (optional) | Wrong product story |
| Mapper that reads `row.properties.nics` ARG shape | Sensor JSON will differ |

---

## Same idea, sensor names

Azure today:

```
mock  |  resource-graph
```

Sensor skeleton:

```
mock  |  sensor
```

| Azure piece | Sensor equivalent |
|-------------|-------------------|
| `azure.js` | `sensor.js` — URL, user/token, timeout |
| `resourceGraphService.js` | `sensorApiService.js` — HTTP to the sensor (**empty / not implemented**) |
| ARG fixture JSON | Sensor-shaped fixture JSON |
| `DefaultAzureCredential` | Later: username/password or API token |
| `$skipToken` | Later: whatever paging the sensor uses |

`defenderService.js` stays a **facade**. It only picks `mock` or `sensor`. Orchestrator still calls `fetchDevices()` and never knows Azure vs sensor.

---

## Suggested folder structure

```
defender_iot_sensor/
  src/
    config/
      sensor.js              # SENSOR_BASE_URL, user, token, source=mock|sensor
      sequelize.js
      development.env        # no AZURE_* keys
    services/
      defenderServices/
        defenderService.js   # facade: mock | sensor
        mockSensorService.js # reads fixture (works today)
        sensorApiService.js  # TODO: real HTTP when client gives API
      assetMapperService.js  # fixture/sensor JSON → assets table
    sources/
      fixtures/
        sensor-devices.json  # fake sensor payload, not ARG rows
    orchestrators/
      deviceSyncOrchestrator.js   # unchanged flow
    controllers / routes / repositories / models
```

Default: **`DEFENDER_SOURCE=mock`**. Sync works with fixtures. No sensor, no Azure.

---

## How the skeleton should behave

### `mock`

Load `sensor-devices.json`. Shape should look like a **sensor**, not Resource Graph (`id` + `properties.nics`). Use a small invented sample and document: *replace when the client sends a real response*.

### `sensor` (placeholder)

`sensorApiService.fetchDevices()` should:

- read `SENSOR_BASE_URL` (and later auth)
- **not** call Azure
- throw a clear error, e.g. *“Sensor API not implemented — waiting on client spec”*

That is the same idea as Azure: live path exists, but is empty until credentials/API exist.

### Mapper

Map **from the fixture shape** into `assets`. When the real API arrives, change **only** the mapper + `sensorApiService`. Do not change upsert or GET APIs.

---

## Config to plan (no values until the client)

```
DEFENDER_SOURCE=mock          # or sensor later
SENSOR_BASE_URL=              # e.g. https://sensor.local
SENSOR_USERNAME=
SENSOR_PASSWORD=              # or SENSOR_API_TOKEN
SENSOR_TIMEOUT_MS=30000
```

Optional later: `SENSOR_URLS=` (many sensors). Skeleton can support **one** URL first.

No Tenant / Client / Secret / Subscription.

---

## What you fill in later (when the client asks)

1. Auth (token vs basic) in `sensorApiService`
2. Exact path (e.g. `/api/v1/devices`)
3. Paging (their fields, not `$skipToken`)
4. Real JSON → update fixture + mapper
5. One vs many sensors
6. Deploy on-site vs VPN

---

## Questions to ask the client

### One sensor or many?

A **sensor** is the Defender for IoT box on the plant network. It has its own API and device list.

- **One sensor** — single URL; fetch all devices; upsert into Postgres.
- **Many sensors** — each has its own URL and login; merge into the same table; watch duplicates on `external_id`.

### Can this server reach the sensor, or must the app run on-site?

The sensor API is usually **inside the factory network**, not on the public internet.

- **Reachable** (VPN / private link) → keep the app where it is; set sensor URL + credentials.
- **Not reachable** → Azure credentials will not help; deploy this service **on-site** next to the sensor.

---

## How to explain it to the client

> Azure and sensor are two **adapters**. Same sync, same Postgres, same UI. This repo is the sensor adapter: mock works now; live HTTP is a stub until we have the sensor API and network path.

---

## Order of work (when implementing)

1. Strip Azure packages and config from `defender_iot_sensor` only
2. Rename config/providers to sensor
3. Add sensor-shaped fixture + mock
4. Add `sensorApiService` stub
5. Point mapper at the fixture shape
6. Leave live HTTP until the client gives a sample

**Copy 2** stays Azure. **`defender_iot_sensor`** stays the reusable on-prem skeleton.
