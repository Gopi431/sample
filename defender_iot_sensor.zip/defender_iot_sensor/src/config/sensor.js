const dotenv = require("dotenv");
const path = require("path");
dotenv.config({
  path: path.resolve(__dirname, `./${process.env.NODE_ENV || "development"}.env`),
});

/**
 * On-prem Defender for IoT OT sensor.
 *
 * defender.source:
 *   - "mock"   : local fixture JSON
 *   - "sensor" : GET https://<sensor>/api/v1/devices/ with SENSOR_API_TOKEN
 *
 * Token: sensor console → System Settings → Integrations → Access Tokens.
 * Sensors often use a self-signed cert; SENSOR_TLS_REJECT_UNAUTHORIZED=false matches curl -k.
 */
module.exports = {
  defender: {
    source: (process.env.DEFENDER_SOURCE || "mock").toLowerCase(),
  },
  sensor: {
    baseUrl: `${process.env.SENSOR_BASE_URL || ""}`.trim(),
    apiToken: `${process.env.SENSOR_API_TOKEN || ""}`.trim(),
    timeoutMs: parseInt(process.env.SENSOR_TIMEOUT_MS || "30000", 10) || 30000,
    tlsRejectUnauthorized: process.env.SENSOR_TLS_REJECT_UNAUTHORIZED === "true",
  },
};
