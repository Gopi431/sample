const validator = require("validator");
const LoggerCustomUtils = require("../utils/loggerCustoms");
const logger = new LoggerCustomUtils("AssetMapperService");

const TEXT_DEFAULT = "";

/**
 * Maps sensor device rows onto public.assets.
 * Supports the OT sensor API shape (id, ipAddresses, operatingSystem, …)
 * and the local fixture shape (ipAddress, os, …).
 */
class AssetMapperService {
  first(list) {
    return Array.isArray(list) && list.length ? list[0] : null;
  }

  toIp(value) {
    return value && validator.isIP(String(value)) ? String(value) : TEXT_DEFAULT;
  }

  toText(value, fallback = TEXT_DEFAULT) {
    if (value == null || value === "") return fallback;
    return String(value);
  }

  toIso(value) {
    if (value == null || value === "") return new Date().toISOString();
    if (typeof value === "number") return new Date(value).toISOString();
    return String(value);
  }

  protocolName(row) {
    const p = this.first(row.protocols);
    if (!p) return row.protocol || null;
    return p.name || null;
  }

  firmwareText(row) {
    const fw = this.first(row.firmware);
    if (!fw) return this.toText(row.firmware);
    return this.toText(fw.firmwareVersion);
  }

  modelText(row) {
    const fw = this.first(row.firmware);
    return this.toText(row.model, this.toText(fw?.model, "Unknown"));
  }

  mapAsset(row) {
    const id = this.toText(row.id, this.toText(row.name, "unknown"));
    const ip = this.toIp(this.first(row.ipAddresses) || row.ipAddress);
    const authorized = row.authorized;

    return {
      id,
      name: this.toText(row.name, "unknown"),
      type: this.toText(row.type, "Unknown"),
      category: this.toText(row.category, this.toText(row.type, "Endpoint")),
      criticality: this.toText(row.criticality, "Medium"),
      vendor: this.toText(row.vendor, "Unknown"),
      model: this.modelText(row),
      os: this.toText(row.operatingSystem, this.toText(row.os, "Unknown")),
      osVersion: this.toText(row.osVersion),
      firmware: this.firmwareText(row),
      patchLevel: this.toText(row.patchLevel),
      vulnerabilities: Number(row.vulnerabilities) || 0,
      exposureScore: Number(row.exposureScore) || 0,
      lastSeen: this.toIso(row.lastSeen),
      ageYears: Number(row.ageYears) || 0,
      eolDate: this.toText(row.eolDate),
      lifecycle: this.toText(row.lifecycle, "green"),
      status: authorized === false ? "inactive" : this.toText(row.status, "active"),
      site: this.toText(row.site),
      businessUnit: this.toText(row.businessUnit),
      defenderDeviceId: id,
      iotHub: row.iotHub || null,
      networkZone: this.toText(row.networkZone, null) || null,
      macAddress: this.first(row.macAddresses) || row.macAddress || null,
      ipAddress: ip,
      protocol: this.protocolName(row),
      syncedAt: new Date(),
    };
  }

  mapAssets(rows) {
    const functionName = "mapAssets";
    try {
      return rows.map((row) => this.mapAsset(row));
    } catch (error) {
      logger.error(functionName, `Error mapping assets: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to map assets",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new AssetMapperService();
