const LoggerCustomUtils = require("../../utils/loggerCustoms");
const mockDevices = require("../../sources/fixtures/sensor-devices.json");
const logger = new LoggerCustomUtils("MockSensorService");

/**
 * Mock on-prem sensor provider.
 * Returns fixture rows in a simple sensor-like shape (not Azure Resource Graph).
 * Replace sensor-devices.json when the client sends a real sample.
 */
class MockSensorService {
  constructor() {
    this.sourceName = "mock";
  }

  async fetchDevices() {
    const functionName = "fetchDevices";
    try {
      logger.info(functionName, `Returning ${mockDevices.length} mock sensor devices`);
      return mockDevices;
    } catch (error) {
      logger.error(functionName, `Error loading mock sensor devices: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to load mock sensor devices",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new MockSensorService();
