const axios = require("axios");
const https = require("https");
const LoggerCustomUtils = require("../../utils/loggerCustoms");
const config = require("../../config/sensor");
const logger = new LoggerCustomUtils("SensorApiService");

/**
 * Live on-prem Defender for IoT OT sensor.
 * GET /api/v1/devices/ with Authorization: <access token>
 * Token is created on the sensor: System Settings → Integrations → Access Tokens.
 */
class SensorApiService {
  constructor() {
    this.sourceName = "sensor";
  }

  getHttpsAgent() {
    return new https.Agent({ rejectUnauthorized: config.sensor.tlsRejectUnauthorized });
  }

  async fetchDevices() {
    const functionName = "fetchDevices";
    const { baseUrl, apiToken, timeoutMs } = config.sensor;

    if (!baseUrl) {
      throw { message: "DEFENDER_SOURCE=sensor requires SENSOR_BASE_URL", status: 500 };
    }
    if (!apiToken) {
      throw { message: "DEFENDER_SOURCE=sensor requires SENSOR_API_TOKEN (sensor: Integrations → Access Tokens)", status: 500 };
    }

    const url = `${baseUrl.replace(/\/+$/, "")}/api/v1/devices/`;

    try {
      logger.info(functionName, `Fetching devices from sensor ${url}`);
      const response = await axios.get(url, {
        headers: { Authorization: apiToken },
        timeout: timeoutMs,
        httpsAgent: this.getHttpsAgent(),
      });

      const rows = Array.isArray(response.data) ? response.data : [];
      logger.info(functionName, `Fetched ${rows.length} devices from sensor`);
      return rows;
    } catch (error) {
      const status = error.response?.status || error.status || 500;
      const detail = error.response?.data?.message || error.message;
      logger.error(functionName, `Error fetching devices from sensor: ${detail}`, error);
      throw {
        message: detail || "Failed to fetch devices from sensor",
        status,
      };
    }
  }
}

module.exports = new SensorApiService();
