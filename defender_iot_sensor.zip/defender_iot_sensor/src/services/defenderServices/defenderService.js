const LoggerCustomUtils = require("../../utils/loggerCustoms");
const config = require("../../config/sensor");
const mockSensorService = require("./mockSensorService");
const sensorApiService = require("./sensorApiService");
const logger = new LoggerCustomUtils("DefenderService");

const PROVIDERS = {
  mock: mockSensorService,
  sensor: sensorApiService,
};

/**
 * Facade over Defender for IoT sources.
 * Callers never care whether data comes from fixtures or the sensor API.
 */
class DefenderService {
  constructor() {
    this.provider = PROVIDERS[config.defender.source];
    if (!this.provider) {
      throw new Error(`Unknown DEFENDER_SOURCE "${config.defender.source}". Use one of: ${Object.keys(PROVIDERS).join(", ")}`);
    }
    this.sourceName = this.provider.sourceName;
  }

  async fetchDevices() {
    const functionName = "fetchDevices";
    try {
      logger.info(functionName, `Fetching devices using source: ${this.sourceName}`);
      return await this.provider.fetchDevices();
    } catch (error) {
      logger.error(functionName, `Error fetching devices: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to fetch devices from Defender for IoT",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new DefenderService();
