const logger = require("./logger")(__filename);

/**
 * Responsible for communication with Atom related services class and sending a response.
 * @module LoggerCustom
 *
 */

function LoggerCustom(name) {
  this.fileName = name;
}

LoggerCustom.prototype.error = function error(methodName = "Updated method name", message = "", err = "-") {
  logger.error(err?.stack||err?.message||message, {
    timestamp: new Date().toString(),
    fileName: this.fileName,
    methodName,
    error: err.stack || err.message || JSON.stringify(err),
  });
};
LoggerCustom.prototype.info = function info(methodName = "Updated method name", message = "", data = "") {
  logger.info(message, {
    timestamp: new Date().toString(),
    fileName: this.fileName,
    methodName,
    data: JSON.stringify(data),
  });
};
LoggerCustom.prototype.debug = function debug(methodName = "Updated method name", message = "", data = "") {
  logger.debug(message, {
    timestamp: new Date().toString(),
    fileName: this.fileName,
    methodName,
    data: data,
  });
};

LoggerCustom.prototype.warn = function warn(methodName = "Updated method name", message = "", data = "") {
  logger.warn(message, {
    timestamp: new Date().toString(),
    fileName: this.fileName,
    methodName,
    data: data,
  });
};

module.exports = LoggerCustom;
