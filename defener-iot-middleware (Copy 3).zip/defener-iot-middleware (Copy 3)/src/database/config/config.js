const path = require('path');
var env_name = process.env.NODE_ENV || 'development'
/**
 * To run migrate/seed/other in production change development to <production>
 */
//production
console.log('------- Config.js -----', `${env_name}`)
require('dotenv').config({
    path: path.resolve(__dirname, `../config/${env_name}.env`)
});
module.exports = {
    development: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOSTNAME,
        dialect: process.env.DB_DIALECT,
        pool: {
            "max": 40,
            "min": 0,
            "acquire": 30000,
            "idle": 10000
        },
        "ssl": true,
        logging: false,
        "dialectOptions": {
            "ssl": {
                rejectUnauthorized: false
            }
        },
        "seederStorage": "sequelize",
        "seederStorageTableName": "sequelize_data",
        define: {
            timestamps: false
        }
    },
    production: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOSTNAME,
        dialect: process.env.DB_DIALECT,
        pool: {
            "max": 40,
            "min": 0,
            "acquire": 30000,
            "idle": 10000
        },
        "ssl": true,
        // logging: false,
        "dialectOptions": {
            "ssl": {
                rejectUnauthorized: false
            }
        },
        "seederStorage": "sequelize",
        "seederStorageTableName": "sequelize_data",
        define: {
            timestamps: false
        }
    },
    test: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOSTNAME,
        dialect: process.env.DB_DIALECT,
        pool: {
            "max": 40,
            "min": 0,
            "acquire": 30000,
            "idle": 10000
        },
        "ssl": true,
        "dialectOptions": {
            "ssl": {
                "require": true
            }
        },
        "seederStorage": "sequelize",
        "seederStorageTableName": "sequelize_data",
        define: {
            timestamps: false
        }
    },

    devml: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOSTNAME,
        dialect: process.env.DB_DIALECT,
        pool: {
            "max": 40,
            "min": 0,
            "acquire": 30000,
            "idle": 10000
        },
        "ssl": true,
        "dialectOptions": {
            "ssl": {
                rejectUnauthorized: false
            }
        },
        "seederStorage": "sequelize",
        "seederStorageTableName": "sequelize_data",
        define: {
            timestamps: false
        }
    },
    devsearch: {
        username: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        host: process.env.DB_HOSTNAME,
        dialect: process.env.DB_DIALECT,
        pool: {
            "max": 40,
            "min": 0,
            "acquire": 30000,
            "idle": 10000
        },
        "ssl": true,
        "dialectOptions": {
            "ssl": {
                "require": true
            }
        },
        "seederStorage": "sequelize",
        "seederStorageTableName": "sequelize_data",
        define: {
            timestamps: false
        }
    }
};
