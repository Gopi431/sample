module.exports.getFileDirectory = function getFileDirectory() {
    return new Promise(async (resolve, reject) => {
        try {
            let fileName = `${__dirname}`;
            console.log(fileName);
            resolve(fileName);
        } catch (ex) {
            reject(ex)
        }
    });
}