const createError = require("http-errors");
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
// const swaggerUi = require("swagger-ui-express");

var app = express();
var bodyParser = require("body-parser");

const env = process.env.NODE_ENV || "development";

app.use(
  bodyParser.json({
    limit: "50mb",
  })
);
app.use(
  bodyParser.urlencoded({
    limit: "50mb",
    extended: true,
  })
);

app.use(express.json());
app.use(
  express.urlencoded({
    extended: false,
  })
);
app.use(cookieParser());
app.enable("trust proxy");
var corsOptionsDelegate = function (req, callback) {
  var corsOptions;
  corsOptions = {
    origin: [],
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], // Allow required methods
    allowedHeaders: ["Content-Type", "Authorization"], // Allow necessary headers
    exposedHeaders: ["Content-Range", "X-Content-Range", "Content-Disposition"],
    credentials: true,
  };
  callback(null, corsOptions); // callback expects two parameters: error and options
};

app.use(cors(corsOptionsDelegate));


/**
 * Swagger Documentation
 */
// const swa`ggerDocument = require("./content-ai-docs/swagger/configuration");
// var options = {};
// app.use("/`content-ai/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument, options));

app.all("/content-transformer", function (req, res) {
  res.json({
    message: "Content AI application server is running...!",
  });
});

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

app.use(logErrors);

function logErrors(err, req, res, next) {
  console.error(err.stack);
  next(err);
}

module.exports = app;
