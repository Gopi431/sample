/**
 * Read the Defender for IoT device inventory CSV from Azure Blob Storage.
 *
 * Runs on an Azure VM and authenticates with the VM's managed identity
 * (falls back to Azure CLI / env credentials when run locally).
 *
 * Required role for the VM managed identity:
 *   Storage Blob Data Reader on the storage account (or the d4iot container)
 */

const { BlobServiceClient } = require("@azure/storage-blob");
const { DefaultAzureCredential } = require("@azure/identity");
const { parse } = require("csv-parse/sync");
const assetMapperService = require("./assetMapperService");
const assetRepository = require("../repositories/assetRepository");
const LoggerCustomUtils = require("../utils/loggerCustoms");
const logger = new LoggerCustomUtils("BlobInventoryService");

// --------------- Configuration ---------------
const STORAGE_ACCOUNT = process.env.STORAGE_ACCOUNT || "";
const CONTAINER_NAME = process.env.CONTAINER_NAME || "";
const BLOB_PREFIX = process.env.BLOB_PREFIX || "";

// For a user-assigned identity, set AZURE_CLIENT_ID on the VM.
const credential = new DefaultAzureCredential({
  managedIdentityClientId: process.env.AZURE_CLIENT_ID,
});

const blobServiceClient = new BlobServiceClient(
  `https://${STORAGE_ACCOUNT}.blob.core.windows.net`,
  credential
);
const containerClient = blobServiceClient.getContainerClient(CONTAINER_NAME);

/** Return the name of the most recently modified d4iot_*.csv blob. */
async function getLatestBlobName() {
  let latest = null;

  for await (const blob of containerClient.listBlobsFlat({ prefix: BLOB_PREFIX })) {
    if (!blob.name.endsWith(".csv")) continue;
    if (!latest || blob.properties.lastModified > latest.properties.lastModified) {
      latest = blob;
    }
  }

  if (!latest) {
    throw new Error(`No ${BLOB_PREFIX}*.csv files found in container '${CONTAINER_NAME}'`);
  }
  return latest.name;
}

/** Download a blob and return its content as text. */
async function downloadBlobAsText(blobName) {
  const blobClient = containerClient.getBlobClient(blobName);
  const buffer = await blobClient.downloadToBuffer();
  return buffer.toString("utf8");
}

/**
 * Reads the device inventory CSV (the latest one when blobName is not given).
 *
 * Never throws. Returns one of:
 *   { status: "completed", blobName, count, devices }
 *   { status: "failed", error }           could not list / download / parse the blob
 */
async function readDeviceInventory(blobName) {
  const functionName = "readDeviceInventory";
  try {
    const name = blobName || (await getLatestBlobName());
    const csvText = await downloadBlobAsText(name);

    const devices = parse(csvText, {
      columns: true, // use header row as object keys
      bom: true, // strip UTF-8 BOM if present
      skip_empty_lines: true,
      trim: true,
    });

    logger.info(functionName, `Read ${name} from ${STORAGE_ACCOUNT}/${CONTAINER_NAME}: ${devices.length} devices`);
    return { status: "completed", blobName: name, count: devices.length, devices };
  } catch (error) {
    logger.error(functionName, `Reading device inventory failed: ${error.message}`, error);
    return { status: "failed", error: error.message };
  }
}

/**
 * Reads the device inventory CSV and saves its devices to Postgres (insert new, update existing by Id).
 *
 * Never throws. Returns one of:
 *   { status: "completed", blobName, rows, saved, skipped }
 *   { status: "failed", error }           could not read the blob or save to Postgres
 */
async function importDeviceInventory(blobName) {
  const functionName = "importDeviceInventory";
  const inventory = await readDeviceInventory(blobName);
  if (inventory.status !== "completed") return inventory;

  try {
    const assets = assetMapperService.mapAssets(inventory.devices);
    const saved = await assetRepository.upsertAssets(assets);

    const result = { status: "completed", blobName: inventory.blobName, rows: inventory.count, saved, skipped: inventory.count - assets.length };
    logger.info(functionName, `${result.blobName}: ${result.rows} rows, ${saved} saved, ${result.skipped} skipped`);
    return result;
  } catch (error) {
    logger.error(functionName, `Saving device inventory failed: ${error.message}`, error);
    return { status: "failed", error: error.message };
  }
}

module.exports = { readDeviceInventory, importDeviceInventory };
