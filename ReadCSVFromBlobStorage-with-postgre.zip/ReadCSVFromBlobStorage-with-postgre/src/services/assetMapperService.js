const LoggerCustomUtils = require("../utils/loggerCustoms");
const logger = new LoggerCustomUtils("AssetMapperService");

const TEXT_DEFAULT = "";

/**
 * Maps rows of the Defender for IoT device inventory CSV onto public.assets.
 *
 * The names inside row["..."] must match the CSV header names exactly.
 * If the file uses different headers, change them here.
 */
class AssetMapperService {
  // Cells like "10.0.0.1, 10.0.0.2" hold several values; keep the first one.
  first(value) {
    return (value || "").split(/[,;\s]+/)[0];
  }

  toText(value, fallback = TEXT_DEFAULT) {
    if (value == null || value === "") return fallback;
    return String(value);
  }

  mapAsset(row) {
    const macAddress = this.first(row["MAC Address"]);
    const ipAddress = this.first(row["IP Address"]);
    // MAC is the most stable identifier; fall back to IP when there is no MAC.
    const id = macAddress || ipAddress;

    return {
      id,
      name: this.toText(row["Name"], "unknown"),
      type: this.toText(row["Type"], "Unknown"),
      category: this.toText(row["Category"], "Endpoint"),
      criticality: "Medium",
      vendor: this.toText(row["Vendor"], "Unknown"),
      model: this.toText(row["Model"], "Unknown"),
      os: this.toText(row["OS Platform"], "Unknown"),
      osVersion: TEXT_DEFAULT,
      firmware: this.toText(row["Firmware Version"]),
      patchLevel: TEXT_DEFAULT,
      vulnerabilities: 0,
      exposureScore: 0,
      lastSeen: this.toText(row["Last Activity"], new Date().toISOString()),
      ageYears: 0,
      eolDate: TEXT_DEFAULT,
      lifecycle: "green",
      status: /^(no|false)$/i.test(row["Authorized"] || "") ? "inactive" : "active",
      site: this.toText(row["Site"]),
      businessUnit: TEXT_DEFAULT,
      defenderDeviceId: id,
      iotHub: null,
      networkZone: this.toText(row["Zone"], null),
      macAddress: macAddress || null,
      ipAddress,
      protocol: this.toText(row["Protocols"], null),
      syncedAt: new Date(),
    };
  }

  /**
   * Rows without MAC and IP cannot be identified, so they are skipped.
   * Postgres rejects the same Id twice in one upsert, so the last row per Id is kept.
   */
  mapAssets(rows) {
    const functionName = "mapAssets";
    try {
      const assets = rows.map((row) => this.mapAsset(row)).filter((asset) => asset.id);
      return [...new Map(assets.map((asset) => [asset.id, asset])).values()];
    } catch (error) {
      logger.error(functionName, `Error mapping assets: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to map assets",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new AssetMapperService();
