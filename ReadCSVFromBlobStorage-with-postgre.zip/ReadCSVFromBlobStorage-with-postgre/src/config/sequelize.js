const { Sequelize } = require("sequelize");
const LoggerCustomUtils = require("../utils/loggerCustoms");
const logger = new LoggerCustomUtils("sequelize");

/**
 * Shared Sequelize instance.
 * Env keys: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT.
 * Local Postgres: DB_SSL=false. Azure Database for PostgreSQL: DB_SSL=true.
 */
const sequelize = new Sequelize({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || "5432", 10),
  database: process.env.DB_NAME,
  username: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  dialect: "postgres",
  logging: false,
  pool: { max: 10, min: 0, acquire: 30000, idle: 10000 },
  dialectOptions: process.env.DB_SSL === "true" ? { ssl: { require: true, rejectUnauthorized: false } } : {},
  define: { underscored: false, timestamps: false, freezeTableName: true },
});

let isConnected = false; // Track connection status

const connectToDatabase = async () => {
  const functionName = "connectToDatabase";
  if (isConnected) {
    logger.info(functionName, "Using existing PostgreSQL connection");
    return sequelize;
  }

  try {
    await sequelize.authenticate();

    // DB_SYNC=true creates missing tables from the models (dev only; tables are managed manually in Azure).
    if (process.env.DB_SYNC === "true") {
      await sequelize.sync();
      logger.info(functionName, "Sequelize sync complete (missing tables created)");
    }

    isConnected = true;
    logger.info(functionName, `PostgreSQL connected successfully (${process.env.DB_HOST}/${process.env.DB_NAME})`);

    return sequelize;
  } catch (error) {
    logger.error(functionName, `PostgreSQL connection failed: ${error.message}`, error);
    process.exit(1); // Exit the process if PostgreSQL fails to connect
  }
};

// Handle graceful shutdowns
const closeDatabase = async () => {
  if (isConnected) {
    await sequelize.close();
    isConnected = false;
    logger.info("closeDatabase", "PostgreSQL connection closed");
  }
};

// Handle Node.js process termination
process.on("SIGINT", async () => {
  await closeDatabase();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await closeDatabase();
  process.exit(0);
});

module.exports = {
  sequelize,
  connectToDatabase,
  closeDatabase,
};
