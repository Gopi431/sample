const path = require("path");
const dotenv = require("dotenv");

// Load env first: the storage account, container and database settings are read from process.env.
dotenv.config({
  path: path.resolve(__dirname, `./src/config/${process.env.NODE_ENV || "development"}.env`),
  quiet: true,
});

const cron = require("node-cron");
const app = require("./src/app");
require("./src/models/assetModel");
const { connectToDatabase } = require("./src/config/sequelize");
const { syncLatestDeviceInventory } = require("./src/services/blobInventoryService");
const LoggerCustomUtils = require("./src/utils/loggerCustoms");
const logger = new LoggerCustomUtils("index");

const PORT = parseInt(process.env.PORT || "3000", 10);

// How often to check Blob Storage for a new CSV (cron format). Default: every 15 minutes.
const SYNC_CRON = process.env.SYNC_CRON || "*/15 * * * *";

async function start() {
  // Connect to PostgreSQL before accepting traffic (exits the process on failure)
  await connectToDatabase();

  app.listen(PORT, () => {
    logger.info("start", `API listening on http://localhost:${PORT}/api`);
  });

  // Periodic Blob -> Postgres sync (same as POST /api/devices/import, but skips an unchanged CSV)
  if (process.env.SYNC_ENABLED === "true") {
    if (!cron.validate(SYNC_CRON)) {
      throw new Error(`Invalid SYNC_CRON: "${SYNC_CRON}"`);
    }
    cron.schedule(SYNC_CRON, syncLatestDeviceInventory);
    logger.info("start", `Device inventory sync scheduled: ${SYNC_CRON}`);
  }
}

start().catch((error) => {
  logger.error("start", `Failed to start: ${error.message}`, error);
  process.exit(1);
});
