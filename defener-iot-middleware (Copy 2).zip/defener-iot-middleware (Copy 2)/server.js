const path = require("path");
const http = require("http");
const dotenv = require("dotenv");
const logger = require("./src/utils/logger")(path.basename(__filename));

// Load environment variables
dotenv.config({
  path: path.resolve(__dirname, `./src/config/${process.env.NODE_ENV}.env`),
});

const app = require("./app");
require("./src/models");
const { connectToDatabase } = require("./src/config/sequelize");

// Get ports
const port = normalizePort(process.env.PORT || "3000");
app.set("port", port);

// Create HTTP servers
const server = http.createServer(app);


(async () => {
  try {
    // Connect to PostgreSQL before accepting traffic (exits the process on failure)
    await connectToDatabase();

    // Start Express server
    server.listen(port, () => {
      logger.info({
        message: `HTTP server running on port ${port}`,
        fileName: path.basename(__filename),
        methodName: "HTTPServerRunning ",
      });
    });
    server.on("error", onError);
    server.on("listening", onListening);

  } catch (error) {
    logger.error({
      message: `Failed to start server: ${error.message}`,
      fileName: path.basename(__filename),
      methodName: "startup",
    });
    process.exit(1);
  }
})();

/**
 * Normalize a port into a number, string, or false.
 */
function normalizePort(val) {
  const port = parseInt(val, 10);
  if (isNaN(port)) return val;
  if (port >= 0) return port;
  return false;
}

/**
 * Event listener for HTTP server "error" event.
 */
function onError(error) {
  if (error.syscall !== "listen") throw error;
  const bind = typeof port === "string" ? "Pipe " + port : "Port " + port;
  switch (error.code) {
    case "EACCES":
      logger.error(`${bind} requires elevated privileges`);
      process.exit(1);
    case "EADDRINUSE":
      logger.error(`${bind} is already in use`);
      process.exit(1);
    default:
      throw error;
  }
}

/**
 * Event listener for HTTP server "listening" event.
 */
function onListening() {
  const addr = server.address();
  const bind = typeof addr === "string" ? `pipe ${addr}` : `port ${addr.port}`;
  logger.info({
    message: `Server listening on ${bind}`,
    fileName: path.basename(__filename),
    methodName: "listeningServer ",
  });
}
