const validator = require("validator");
const LoggerCustomUtils = require("../utils/loggerCustoms");
const logger = new LoggerCustomUtils("AssetMapperService");

const TEXT_DEFAULT = "";

/**
 * Maps Azure Resource Graph device rows onto public.assets (defender_iot.sql).
 * Columns that Defender does not send get dump-compatible defaults (NOT NULL texts cannot be null).
 */
class AssetMapperService {
  toIp(value) {
    return value && validator.isIP(String(value)) ? String(value) : TEXT_DEFAULT;
  }

  toText(value, fallback = TEXT_DEFAULT) {
    if (value == null || value === "") return fallback;
    return String(value);
  }

  mapAsset(row) {
    const p = row.properties || {};
    const nic = Array.isArray(p.nics) && p.nics.length ? p.nics[0] : {};
    const lastSeen = p.lastSeen || new Date().toISOString();

    return {
      id: row.id,
      name: this.toText(p.deviceName, this.toText(row.name, "unknown")),
      type: this.toText(p.deviceSubTypeDisplayName, this.toText(p.deviceTypeDisplayName, "Unknown")),
      category: this.toText(p.deviceTypeDisplayName, "Endpoint"),
      criticality: "Medium",
      vendor: this.toText(p.hardware?.vendor, "Unknown"),
      model: this.toText(p.hardware?.model, "Unknown"),
      os: this.toText(p.operatingSystem, "Unknown"),
      osVersion: TEXT_DEFAULT,
      firmware: TEXT_DEFAULT,
      patchLevel: TEXT_DEFAULT,
      vulnerabilities: 0,
      exposureScore: 0,
      lastSeen: this.toText(lastSeen),
      ageYears: 0,
      eolDate: TEXT_DEFAULT,
      lifecycle: "green",
      status: p.authorizationState === "Unauthorized" ? "inactive" : "active",
      site: this.toText(p.sensor?.site),
      businessUnit: TEXT_DEFAULT,
      defenderDeviceId: this.toText(row.name, null) || null,
      iotHub: null,
      networkZone: this.toText(p.purdueLevel, null) || null,
      macAddress: nic.macAddress || null,
      ipAddress: this.toIp(nic.ipv4Address),
      protocol: null,
      syncedAt: new Date(),
    };
  }

  mapAssets(rows) {
    const functionName = "mapAssets";
    try {
      return rows.map((row) => this.mapAsset(row));
    } catch (error) {
      logger.error(functionName, `Error mapping assets: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to map assets",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new AssetMapperService();
