const LoggerCustomUtils = require("../../utils/loggerCustoms");
const mockDevices = require("../../utils/mock-data/devices.json");
const logger = new LoggerCustomUtils("MockDefenderService");

/**
 * Mock Defender for IoT provider.
 * Returns fixture rows in the exact shape Azure Resource Graph returns,
 * so the mapper and repository code paths are identical to production.
 */
class MockDefenderService {
  constructor() {
    this.sourceName = "mock";
  }

  async fetchDevices() {
    const functionName = "fetchDevices";
    try {
      logger.info(functionName, `Returning ${mockDevices.length} mock devices`);
      return mockDevices;
    } catch (error) {
      logger.error(functionName, `Error loading mock devices: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to load mock devices",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new MockDefenderService();
