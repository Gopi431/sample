const LoggerCustomUtils = require("../../utils/loggerCustoms");
const config = require("../../config/azure");
const mockDefenderService = require("./mockDefenderService");
const resourceGraphService = require("./resourceGraphService");
const logger = new LoggerCustomUtils("DefenderService");

const PROVIDERS = {
  mock: mockDefenderService,
  "resource-graph": resourceGraphService,
};

/**
 * Facade over the Defender for IoT providers.
 * Picks the provider from config.defender.source so callers never care
 * whether data comes from fixtures or live Azure.
 */
class DefenderService {
  constructor() {
    this.provider = PROVIDERS[config.defender.source];
    if (!this.provider) {
      throw new Error(`Unknown DEFENDER_SOURCE "${config.defender.source}". Use one of: ${Object.keys(PROVIDERS).join(", ")}`);
    }
    this.sourceName = this.provider.sourceName;
  }

  async fetchDevices() {
    const functionName = "fetchDevices";
    try {
      logger.info(functionName, `Fetching devices using source: ${this.sourceName}`);
      return await this.provider.fetchDevices();
    } catch (error) {
      logger.error(functionName, `Error fetching devices: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to fetch devices from Defender for IoT",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new DefenderService();
