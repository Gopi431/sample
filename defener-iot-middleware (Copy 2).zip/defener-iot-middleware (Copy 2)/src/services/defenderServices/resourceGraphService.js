const { DefaultAzureCredential } = require("@azure/identity");
const { ResourceGraphClient } = require("@azure/arm-resourcegraph");
const LoggerCustomUtils = require("../../utils/loggerCustoms");
const config = require("../../config/azure");
const logger = new LoggerCustomUtils("ResourceGraphService");

/**
 * Live Defender for IoT provider backed by Azure Resource Graph.
 * Runs a KQL query against the iotsecurityresources table and follows
 * skipToken pagination until every row is read.
 */
const DEVICES_QUERY = `
  iotsecurityresources
  | where type == 'microsoft.iotsecurity/locations/devicegroups/devices'
  | order by id asc
`;

class ResourceGraphService {
  constructor() {
    this.sourceName = "resource-graph";
    this.client = null;
  }

  getClient() {
    if (!config.azure.subscriptionId) {
      throw { message: "DEFENDER_SOURCE=resource-graph requires AZURE_SUBSCRIPTION_ID", status: 500 };
    }
    if (!this.client) {
      this.client = new ResourceGraphClient(new DefaultAzureCredential());
    }
    return this.client;
  }

  async fetchDevices() {
    const functionName = "fetchDevices";
    try {
      const client = this.getClient();
      const rows = [];
      let skipToken;

      do {
        const response = await client.resources({
          subscriptions: [config.azure.subscriptionId],
          query: DEVICES_QUERY,
          options: { resultFormat: "objectArray", top: config.resourceGraph.pageSize, skipToken },
        });
        rows.push(...response.data);
        skipToken = response.skipToken;
      } while (skipToken);

      logger.info(functionName, `Fetched ${rows.length} devices from Azure Resource Graph`);
      return rows;
    } catch (error) {
      logger.error(functionName, `Error fetching devices from Azure Resource Graph: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to fetch devices from Azure Resource Graph",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new ResourceGraphService();
