const LoggerCustomUtils = require("../utils/loggerCustoms");
const fileOwnerName = "DeviceController";
const logger = new LoggerCustomUtils(fileOwnerName);
const deviceSyncOrchestrator = require("../orchestrators/deviceSyncOrchestrator");
const responseHandler = require("../exceptionHandler/response-manager");
const { StatusCodes } = require("http-status-codes");

class DeviceController {
  async syncDevices(req, res) {
    const methodName = "syncDevices";
    logger.info(methodName, "Request received to sync assets from Defender for IoT");

    try {
      const result = await deviceSyncOrchestrator.syncDevices();
      logger.info(methodName, "Assets synced successfully", result);
      return responseHandler.sendSuccessResponse(req, res, result, "Assets synced successfully", StatusCodes.OK);
    } catch (error) {
      logger.error(methodName, error.message || "Failed to sync assets", { stack: error.stack, requestId: req.id });
      return res.status(error.status || StatusCodes.INTERNAL_SERVER_ERROR).json({
        error: error.message || error.content || "Internal Server Error",
      });
    }
  }

  async getDevices(req, res) {
    const methodName = "getDevices";
    logger.info(methodName, "Request received to fetch assets", { query: req.query });

    try {
      const result = await deviceSyncOrchestrator.getDevices(req.query);
      logger.info(methodName, "Assets fetched successfully", { totalAssets: result.count });
      return responseHandler.sendSuccessResponse(req, res, result, "Assets fetched successfully", StatusCodes.OK);
    } catch (error) {
      logger.error(methodName, error.message || "Failed to fetch assets", { stack: error.stack, requestId: req.id });
      return res.status(error.status || StatusCodes.INTERNAL_SERVER_ERROR).json({
        error: error.message || error.content || "Internal Server Error",
      });
    }
  }

  async getHierarchy(req, res) {
    const methodName = "getHierarchy";
    logger.info(methodName, "Request received to fetch hierarchy nodes", { query: req.query });

    try {
      const result = await deviceSyncOrchestrator.getHierarchy(req.query);
      return responseHandler.sendSuccessResponse(req, res, result, "Hierarchy nodes fetched successfully", StatusCodes.OK);
    } catch (error) {
      logger.error(methodName, error.message || "Failed to fetch hierarchy nodes", { stack: error.stack, requestId: req.id });
      return res.status(error.status || StatusCodes.INTERNAL_SERVER_ERROR).json({
        error: error.message || error.content || "Internal Server Error",
      });
    }
  }

  async getTrends(req, res) {
    const methodName = "getTrends";
    logger.info(methodName, "Request received to fetch trend data", { query: req.query });

    try {
      const result = await deviceSyncOrchestrator.getTrends(req.query);
      return responseHandler.sendSuccessResponse(req, res, result, "Trend data fetched successfully", StatusCodes.OK);
    } catch (error) {
      logger.error(methodName, error.message || "Failed to fetch trend data", { stack: error.stack, requestId: req.id });
      return res.status(error.status || StatusCodes.INTERNAL_SERVER_ERROR).json({
        error: error.message || error.content || "Internal Server Error",
      });
    }
  }
}

module.exports = new DeviceController();
