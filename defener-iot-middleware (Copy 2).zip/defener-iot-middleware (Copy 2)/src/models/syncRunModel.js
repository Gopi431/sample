const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/sequelize");

/**
 * One row per sync execution, for observability and troubleshooting.
 */
const SyncRunModel = sequelize.define(
  "SyncRun",
  {
    id: { type: DataTypes.BIGINT, primaryKey: true, autoIncrement: true },
    entity: { type: DataTypes.TEXT, allowNull: false },
    source: { type: DataTypes.TEXT, allowNull: false },
    status: { type: DataTypes.TEXT, allowNull: false, defaultValue: "running" },
    rowsFetched: { type: DataTypes.INTEGER, field: "rows_fetched" },
    rowsUpserted: { type: DataTypes.INTEGER, field: "rows_upserted" },
    error: { type: DataTypes.TEXT },
    startedAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW, field: "started_at" },
    finishedAt: { type: DataTypes.DATE, field: "finished_at" },
  },
  {
    tableName: "sync_runs",
    freezeTableName: true,
    underscored: true,
    timestamps: false,
  }
);

module.exports = SyncRunModel;
