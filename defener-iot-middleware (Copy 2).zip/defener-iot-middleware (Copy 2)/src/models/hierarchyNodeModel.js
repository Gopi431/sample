const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/sequelize");

/**
 * Maps to public.hierarchy_nodes from defender_iot.sql.
 */
const HierarchyNodeModel = sequelize.define(
  "HierarchyNode",
  {
    id: { type: DataTypes.TEXT, primaryKey: true, field: "Id" },
    name: { type: DataTypes.TEXT, allowNull: false, field: "Name" },
    level: { type: DataTypes.TEXT, allowNull: false, field: "Level" },
    parentId: { type: DataTypes.TEXT, field: "ParentId" },
    meta: { type: DataTypes.TEXT, allowNull: false, field: "Meta" },
  },
  {
    tableName: "hierarchy_nodes",
    freezeTableName: true,
    underscored: false,
    timestamps: false,
  }
);

module.exports = HierarchyNodeModel;
