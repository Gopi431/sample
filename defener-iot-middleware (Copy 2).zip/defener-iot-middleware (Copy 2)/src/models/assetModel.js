const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/sequelize");


const AssetModel = sequelize.define(
  "Asset",
  {
    id: { type: DataTypes.TEXT, primaryKey: true, field: "Id" },
    name: { type: DataTypes.TEXT, allowNull: false, field: "Name" },
    type: { type: DataTypes.TEXT, allowNull: false, field: "Type" },
    category: { type: DataTypes.TEXT, allowNull: false, field: "Category" },
    criticality: { type: DataTypes.TEXT, allowNull: false, field: "Criticality" },
    vendor: { type: DataTypes.TEXT, allowNull: false, field: "Vendor" },
    model: { type: DataTypes.TEXT, allowNull: false, field: "Model" },
    os: { type: DataTypes.TEXT, allowNull: false, field: "Os" },
    osVersion: { type: DataTypes.TEXT, allowNull: false, field: "OsVersion" },
    firmware: { type: DataTypes.TEXT, allowNull: false, field: "Firmware" },
    patchLevel: { type: DataTypes.TEXT, allowNull: false, field: "PatchLevel" },
    vulnerabilities: { type: DataTypes.INTEGER, allowNull: false, field: "Vulnerabilities" },
    exposureScore: { type: DataTypes.DOUBLE, allowNull: false, field: "ExposureScore" },
    lastSeen: { type: DataTypes.TEXT, allowNull: false, field: "LastSeen" },
    ageYears: { type: DataTypes.DOUBLE, allowNull: false, field: "AgeYears" },
    eolDate: { type: DataTypes.TEXT, allowNull: false, field: "EolDate" },
    lifecycle: { type: DataTypes.TEXT, allowNull: false, field: "Lifecycle" },
    status: { type: DataTypes.TEXT, allowNull: false, field: "Status" },
    site: { type: DataTypes.TEXT, allowNull: false, field: "Site" },
    businessUnit: { type: DataTypes.TEXT, allowNull: false, field: "BusinessUnit" },
    defenderDeviceId: { type: DataTypes.TEXT, field: "DefenderDeviceId" },
    iotHub: { type: DataTypes.TEXT, field: "IotHub" },
    networkZone: { type: DataTypes.TEXT, field: "NetworkZone" },
    macAddress: { type: DataTypes.TEXT, field: "MacAddress" },
    ipAddress: { type: DataTypes.TEXT, field: "IpAddress" },
    protocol: { type: DataTypes.TEXT, field: "Protocol" },
    syncedAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW, field: "SyncedAt" },
  },
  {
    tableName: "assets",
    freezeTableName: true,
    underscored: false,
    timestamps: false,
  }
);

module.exports = AssetModel;
