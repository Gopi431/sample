const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/sequelize");

/**
 * Maps to public.trend_data from defender_iot.sql.
 */
const TrendDataModel = sequelize.define(
  "TrendData",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true, field: "Id" },
    month: { type: DataTypes.TEXT, allowNull: false, field: "Month" },
    year: { type: DataTypes.INTEGER, allowNull: false, field: "Year" },
    monthNumber: { type: DataTypes.INTEGER, allowNull: false, field: "MonthNumber" },
    discovered: { type: DataTypes.INTEGER, allowNull: false, field: "Discovered" },
    active: { type: DataTypes.INTEGER, allowNull: false, field: "Active" },
    inactive: { type: DataTypes.INTEGER, allowNull: false, field: "Inactive" },
  },
  {
    tableName: "trend_data",
    freezeTableName: true,
    underscored: false,
    timestamps: false,
  }
);

module.exports = TrendDataModel;
