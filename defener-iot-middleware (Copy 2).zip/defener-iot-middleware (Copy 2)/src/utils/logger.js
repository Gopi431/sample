const { createLogger, format, transports } = require("winston");
const path = require("path");
require("winston-daily-rotate-file");

const colors = {
  trace: "white",
  debug: "blue",
  info: "green",
  warn: "yellow",
  crit: "red",
  fatal: "red",
};

const options = (prefix) => ({
  level: "debug",
  format: format.combine(
    format.label({
      label: path.basename(prefix),
    }),
    format.colorize({
      colors,
    }),
    format.timestamp({
      format: "YYYY-MM-DD HH:mm:ss",
    }),
    format.printf((info) => {
      const fileName = info.fileName || "unknown";
      const methodName = info.methodName || "unknown";
      return `${info.timestamp} ${info.level} [${fileName}:${methodName}]: ${info.message}`;
    })
  ),
  transports: [
    new transports.Console(),
    new transports.DailyRotateFile({
      filename: "logs/server/content-transformer-app-%DATE%.log",
      datePattern: "YYYY-MM-DD-HH",
      zippedArchive: true,
      maxSize: "20m",
      maxFiles: "5d",
      prepend: true,
      level: "debug",
      format: format.combine(format.uncolorize()),
    }),
    new transports.DailyRotateFile({
      filename: "logs/server/content-transformer-app-%DATE%-Error.log",
      datePattern: "YYYY-MM-DD-HH",
      zippedArchive: true,
      maxSize: "20m",
      maxFiles: "5d",
      prepend: true,
      level: "error",
      format: format.combine(format.uncolorize()),
    }),
  ],
});

// prettier-disable
const logger = (prefix) => createLogger(options(prefix));

module.exports = logger;
