module.exports.AppErrorObject = function AppErrorObject(code, message, responseCode, errorInfo = []) {
    let errorObject = {
        codeNumber: code,
        message: message,
        responseCode: responseCode,
        errorInfo: errorInfo
    }
    return errorObject;
}