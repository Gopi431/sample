const appHelper = require('./app_helper');
const fileOwnerName = "RequestBodyValidationMiddleware"
const LoggerCustomUtils = require('../utils/loggerCustoms');
const logger = new LoggerCustomUtils(fileOwnerName);

/**
 * Responsible for communication with Atom related services class and sending a response.  
 * @module CommonValidationClass            
 * 
 */

function RequestBodyValidationHandler(name) {
    this.fileName = name;
}

RequestBodyValidationHandler.prototype.validateRequest = function validateRequest(req, methodName, errorString) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        let err = appHelper.getAppErrorObject(errorString);
        err.message = errors.array();
        logger.error('Request Exception', {
            timestamp: new Date().toString(),
            fileName: this.fileName,
            methodName,
            error: err.message
        })
        throw err;
    }
};

module.exports = RequestBodyValidationHandler;