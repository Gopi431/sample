const appHelper = require('./app_helper');
const logger = require('../utils/logger')(__filename)

/**
 * Responsible for communication with Atom related services class and sending a response.  
 * @module CommonValidationClass            
 * 
 */

function CommonValidationClass(name) {
    this.fileName = name;
}

CommonValidationClass.prototype.catchBlockException = function catchBlockException(error, methodName, msg, errorString) {
    let err = appHelper.getAppErrorObject(errorString);
    logger.error(msg, {
        timestamp: new Date().toString(),
        fileName: this.fileName,
        methodName,
        error: error.message
    })
    throw err;
};
CommonValidationClass.prototype.generalException = function generalException(methodName, msg, errorString) {
    let err = appHelper.getAppErrorObject(errorString);
    logger.error(msg, {
        timestamp: new Date().toString(),
        fileName: this.fileName,
        methodName,
        error: msg
    })
    throw err;
};
CommonValidationClass.prototype.contentNotFoundException = function contentNotFoundException(methodName, msg, errorString) {
    let err = appHelper.getAppErrorObject(errorString);
    logger.warn(msg, {
        timestamp: new Date().toString(),
        fileName: this.fileName,
        methodName,
        error: msg
    })
    throw err;
};

module.exports = CommonValidationClass;