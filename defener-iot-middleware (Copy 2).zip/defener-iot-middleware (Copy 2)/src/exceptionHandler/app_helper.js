let errors = {};
const appError = require('./app_error');

class AppErrorHelper {
    getAppErrorObject(errorString, code = 0, message = null) {
        var error = errors[errorString];
        if (!error) {
            error = {
                code: 2000,
                message: errorString || 'Bad Request',
                responseCode: 400
            };
        }
        if (code != 0) {

        }
        var errObj = appError.AppErrorObject(error.code, error.message, error.responseCode);
        return errObj
    }

}

var app_error_helper = new AppErrorHelper();
module.exports = app_error_helper;