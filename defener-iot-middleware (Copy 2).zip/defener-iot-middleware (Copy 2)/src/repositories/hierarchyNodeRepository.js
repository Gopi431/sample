const LoggerCustomUtils = require("../utils/loggerCustoms");
const HierarchyNodeModel = require("../models/hierarchyNodeModel");
const logger = new LoggerCustomUtils("HierarchyNodeRepository");

class HierarchyNodeRepository {
  async findNodes({ limit = 100, offset = 0 } = {}) {
    const functionName = "findNodes";
    try {
      return await HierarchyNodeModel.findAll({
        order: [["id", "ASC"]],
        limit,
        offset,
      });
    } catch (error) {
      logger.error(functionName, `Error fetching hierarchy nodes: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to fetch hierarchy nodes",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new HierarchyNodeRepository();
