const LoggerCustomUtils = require("../utils/loggerCustoms");
const SyncRunModel = require("../models/syncRunModel");
const logger = new LoggerCustomUtils("SyncRunRepository");

class SyncRunRepository {
  async startRun(entity, source) {
    const functionName = "startRun";
    try {
      const run = await SyncRunModel.create({ entity, source });
      return run.id;
    } catch (error) {
      logger.error(functionName, `Error starting sync run: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to start sync run",
        status: error.status || 500,
      };
    }
  }

  async completeRun(id, { rowsFetched, rowsUpserted }) {
    const functionName = "completeRun";
    try {
      await SyncRunModel.update({ status: "success", rowsFetched, rowsUpserted, finishedAt: new Date() }, { where: { id } });
    } catch (error) {
      logger.error(functionName, `Error completing sync run ${id}: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to complete sync run",
        status: error.status || 500,
      };
    }
  }

  async failRun(id, cause) {
    const functionName = "failRun";
    try {
      await SyncRunModel.update(
        { status: "failed", error: String(cause?.message || cause), finishedAt: new Date() },
        { where: { id } }
      );
    } catch (error) {
      logger.error(functionName, `Error marking sync run ${id} as failed: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to mark sync run as failed",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new SyncRunRepository();
