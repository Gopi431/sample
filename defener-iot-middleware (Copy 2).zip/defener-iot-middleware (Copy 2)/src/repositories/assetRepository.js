const LoggerCustomUtils = require("../utils/loggerCustoms");
const AssetModel = require("../models/assetModel");
const logger = new LoggerCustomUtils("AssetRepository");

const BATCH_SIZE = 200;

const UPDATE_ON_CONFLICT = Object.keys(AssetModel.getAttributes()).filter((attr) => attr !== "id");

class AssetRepository {
  async upsertAssets(assets) {
    const functionName = "upsertAssets";
    try {
      if (!assets.length) return 0;

      let written = 0;
      for (let i = 0; i < assets.length; i += BATCH_SIZE) {
        const batch = assets.slice(i, i + BATCH_SIZE);
        const rows = await AssetModel.bulkCreate(batch, { updateOnDuplicate: UPDATE_ON_CONFLICT });
        written += rows.length;
      }
      return written;
    } catch (error) {
      logger.error(functionName, `Error upserting assets: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to upsert assets",
        status: error.status || 500,
      };
    }
  }

  async findAssets({ limit = 100, offset = 0 } = {}) {
    const functionName = "findAssets";
    try {
      return await AssetModel.findAll({
        order: [["id", "ASC"]],
        limit,
        offset,
      });
    } catch (error) {
      logger.error(functionName, `Error fetching assets: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to fetch assets",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new AssetRepository();
