const LoggerCustomUtils = require("../utils/loggerCustoms");
const TrendDataModel = require("../models/trendDataModel");
const logger = new LoggerCustomUtils("TrendDataRepository");

class TrendDataRepository {
  async findTrends({ limit = 100, offset = 0 } = {}) {
    const functionName = "findTrends";
    try {
      return await TrendDataModel.findAll({
        order: [
          ["year", "ASC"],
          ["monthNumber", "ASC"],
        ],
        limit,
        offset,
      });
    } catch (error) {
      logger.error(functionName, `Error fetching trend data: ${error.message}`, error);
      throw {
        message: error?.message || "Failed to fetch trend data",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new TrendDataRepository();
