const LoggerCustomUtils = require("../utils/loggerCustoms");
const fileOwnerName = "DeviceSyncOrchestrator";
const logger = new LoggerCustomUtils(fileOwnerName);
const defenderService = require("../services/defenderServices/defenderService");
const assetMapperService = require("../services/assetMapperService");
const assetRepository = require("../repositories/assetRepository");
const hierarchyNodeRepository = require("../repositories/hierarchyNodeRepository");
const trendDataRepository = require("../repositories/trendDataRepository");
const syncRunRepository = require("../repositories/syncRunRepository");

const ENTITY = "assets";

class DeviceSyncOrchestrator {
  async syncDevices() {
    const functionName = "syncDevices";
    const startedAt = Date.now();
    let runId;

    try {
      logger.info(functionName, `Starting asset sync from source: ${defenderService.sourceName}`);
      runId = await syncRunRepository.startRun(ENTITY, defenderService.sourceName);

      const rows = await defenderService.fetchDevices();
      const assets = assetMapperService.mapAssets(rows);
      const upserted = await assetRepository.upsertAssets(assets);

      await syncRunRepository.completeRun(runId, { rowsFetched: rows.length, rowsUpserted: upserted });

      const result = {
        runId,
        source: defenderService.sourceName,
        fetched: rows.length,
        upserted,
        durationMs: Date.now() - startedAt,
      };
      logger.info(functionName, "Asset sync completed successfully", result);
      return result;
    } catch (error) {
      if (runId) {
        await syncRunRepository.failRun(runId, error).catch(() => {});
      }
      logger.error(functionName, error?.message || "Error syncing assets", error);
      throw {
        message: error?.message || "Failed to sync assets",
        status: error.status || 500,
      };
    }
  }

  async getDevices({ limit, offset }) {
    const functionName = "getDevices";
    try {
      const query = {
        limit: Math.min(Number(limit) || 100, 1000),
        offset: Number(offset) || 0,
      };
      logger.info(functionName, "Fetching assets", query);

      const assets = await assetRepository.findAssets(query);
      return { count: assets.length, ...query, assets };
    } catch (error) {
      logger.error(functionName, error?.message || "Error fetching assets", error);
      throw {
        message: error?.message || "Failed to fetch assets",
        status: error.status || 500,
      };
    }
  }

  async getHierarchy({ limit, offset }) {
    const functionName = "getHierarchy";
    try {
      const query = {
        limit: Math.min(Number(limit) || 100, 1000),
        offset: Number(offset) || 0,
      };
      const nodes = await hierarchyNodeRepository.findNodes(query);
      return { count: nodes.length, ...query, nodes };
    } catch (error) {
      logger.error(functionName, error?.message || "Error fetching hierarchy nodes", error);
      throw {
        message: error?.message || "Failed to fetch hierarchy nodes",
        status: error.status || 500,
      };
    }
  }

  async getTrends({ limit, offset }) {
    const functionName = "getTrends";
    try {
      const query = {
        limit: Math.min(Number(limit) || 100, 1000),
        offset: Number(offset) || 0,
      };
      const trends = await trendDataRepository.findTrends(query);
      return { count: trends.length, ...query, trends };
    } catch (error) {
      logger.error(functionName, error?.message || "Error fetching trend data", error);
      throw {
        message: error?.message || "Failed to fetch trend data",
        status: error.status || 500,
      };
    }
  }
}

module.exports = new DeviceSyncOrchestrator();
