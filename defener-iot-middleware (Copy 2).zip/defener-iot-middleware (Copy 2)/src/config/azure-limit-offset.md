# Limit / Offset vs `$skipToken`

Azure Resource Graph has `$top` / `$skip` (like limit / offset), but it is **not** the same as a normal SQL `LIMIT`/`OFFSET` UI, and it is **not** what we use for a full device sync.

## What Azure actually supports

On each Resource Graph request you can pass:

| Idea | ARG option | Limit |
|------|------------|-------|
| Page size | `$top` / `top` | Max 1000 per call |
| Skip N rows | `$skip` / `skip` | Jump into a sorted result set |
| Next chunk when there are more than 1000 | `$skipToken` | Microsoft’s way to walk the full list |

Example: “skip first 2000, take next 1000”:

```js
options: { resultFormat: "objectArray", top: 1000, skip: 2000 }
```

Microsoft’s docs: you should `order by` (we already have `| order by id asc`). If the KQL uses `limit` / `take`, `$skip` is ignored.

## Why we do not use limit/offset for the sync

`POST /api/device/sync-devices` must load **all** devices into Postgres.

- `$skip` + `$top` = one page only (and `$top` cannot be 5000).
- To get everything with skip/offset you would loop `skip = 0, 1000, 2000…` until a short page. That can work, but Azure’s supported “there are more rows” mechanism is `skipToken`, which is what we use.

So for sync: **`skipToken` is the right pagination**, not limit/offset.

## Where normal limit/offset does apply

After data is in Postgres — your existing list API:

```http
GET /api/device/get-devices?limit=20&offset=40
```

That is normal pagination for the UI. It does **not** talk to Azure.

Typical pattern:

1. Sync once (or on a schedule) → Azure `skipToken` loop → all rows in Postgres.
2. UI pages Postgres with `limit` / `offset`.

## If you wanted Azure itself to return “page 3 of 20”

Possible for a **single page** (`skip: 40`, `top: 20`), as long as `top` ≤ 1000.

Caveats:

- You cannot ask Azure for `limit=5000` in one call.
- Large offset (e.g. skip 50,000) is slower and less reliable than `skipToken` for dumping the whole inventory.
- Live Azure paging is a poor fit for a table UI if devices change between clicks (rows shift). Postgres after sync is stable.

## Summary

| Approach | Use it? |
|----------|---------|
| Limit/offset against **Postgres** | Yes — we already have it |
| Limit/offset against **Azure** | Possible per page (`$skip`/`$top`, max 1000) |
| Full Defender inventory **sync** | `skipToken` — what `resourceGraphService.js` does |

DB_HOST=<server>.postgres.database.azure.com
DB_PORT=5432
DB_NAME=<azure db name>
DB_USER=<azure user>
DB_PASSWORD=<azure password>
DB_SSL=true
DB_SYNC=false
