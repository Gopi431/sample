const { Sequelize } = require("sequelize");
const dotenv = require("dotenv");
const path = require("path");
dotenv.config({
  path: path.resolve(__dirname, `./${process.env.NODE_ENV || "development"}.env`),
});
const logger = require("../utils/logger")(path.basename(__filename));

/**
 * Shared Sequelize instance.
 * Env keys: DB_HOST (or DB_HOSTNAME), DB_USER (or DB_USERNAME), DB_PASSWORD, DB_NAME, DB_PORT.
 * Local Postgres: DB_SSL=false. Azure Database for PostgreSQL: DB_SSL=true.
 */
const dbHost = process.env.DB_HOST || process.env.DB_HOSTNAME;
const dbUser = process.env.DB_USER || process.env.DB_USERNAME;

const sequelize = new Sequelize({
  host: dbHost,
  port: parseInt(process.env.DB_PORT || "5432", 10),
  database: process.env.DB_NAME,
  username: dbUser,
  password: process.env.DB_PASSWORD,
  dialect: "postgres",
  logging: false,
  pool: { max: 10, min: 0, acquire: 30000, idle: 10000 },
  dialectOptions: process.env.DB_SSL === "true" ? { ssl: { require: true, rejectUnauthorized: false } } : {},
  define: { underscored: false, timestamps: false, freezeTableName: true },
});

let isConnected = false; // Track connection status

const connectToDatabase = async () => {
  if (isConnected) {
    console.log("Using existing PostgreSQL connection");
    return sequelize;
  }

  try {
    await sequelize.authenticate();

    // DB_SYNC=true creates missing tables from the models (dev only; tables are managed manually in Azure).
    if (process.env.DB_SYNC === "true") {
      await sequelize.sync();
      console.log("Sequelize sync complete (missing tables created)");
    }

    isConnected = true;
    console.log(`PostgreSQL connected successfully (${process.env.DB_HOSTNAME}/${process.env.DB_NAME})`);

    return sequelize;
  } catch (error) {
    console.error("PostgreSQL connection failed:", error.message);
    logger.error({
      message: error?.message || "Failed to start server due to PostgreSQL connection error",
      error,
      methodName: "postgresNotConnected",
      fileName: path.basename(__filename),
    });
    process.exit(1); // Exit the process if PostgreSQL fails to connect
  }
};

// Get active connection instance
const getConnection = () => {
  if (!isConnected) {
    throw new Error("PostgreSQL is not connected. Call connectToDatabase first.");
  }
  return sequelize;
};

// Handle graceful shutdowns
const closeDatabase = async () => {
  if (isConnected) {
    await sequelize.close();
    isConnected = false;
    console.log("PostgreSQL connection closed");
  }
};

// Handle Node.js process termination
process.on("SIGINT", async () => {
  await closeDatabase();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await closeDatabase();
  process.exit(0);
});

module.exports = {
  sequelize,
  connectToDatabase,
  getConnection,
  closeDatabase,
};
