const dotenv = require("dotenv");
const path = require("path");
dotenv.config({
  path: path.resolve(__dirname, `./${process.env.NODE_ENV || "development"}.env`),
});

/**
 * Defender for IoT / Azure configuration.
 *
 * defender.source selects where device data is read from:
 *   - "mock"           : local fixture data shaped like Azure Resource Graph rows (no credentials needed)
 *   - "resource-graph" : live Azure Resource Graph query
 *
 * Authentication for "resource-graph" uses DefaultAzureCredential, which reads
 * AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET locally and falls back
 * to Managed Identity when deployed to Azure.
 */
module.exports = {
  defender: {
    source: (process.env.DEFENDER_SOURCE || "mock").toLowerCase(),
  },
  azure: {
    subscriptionId: `${process.env.AZURE_SUBSCRIPTION_ID || ""}`,
    tenantId: `${process.env.AZURE_TENANT_ID || ""}`,
    clientId: `${process.env.AZURE_CLIENT_ID || ""}`,
    clientSecret: `${process.env.AZURE_CLIENT_SECRET || ""}`,
  },
  resourceGraph: {
    // Resource Graph returns at most 1000 rows per page.
    pageSize: Math.min(parseInt(process.env.RESOURCE_GRAPH_PAGE_SIZE || "1000", 10) || 1000, 1000),
  },
};
