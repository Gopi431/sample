# Azure SDK vs Axios

The Azure SDK is not calling a different API. It wraps the same REST call and handles three details for you: **token refresh**, **retries**, and **`$skipToken` pagination**. Axios can do the same; you write the token call, optional retries, and the page loop yourself.

## 1. Token refresh

Azure access tokens last about **1 hour**.

With axios you typically do:

```js
const { token } = await credential.getToken("https://management.azure.com/.default");
```

That token is a string. After ~60 minutes it is invalid and Azure returns **401**.

The SDK keeps the credential object and, on the next call, gets a new token if the old one is expired. You do not check expiry yourself.

If you call `getToken()` on every request (like the ChatGPT snippet), refresh is not a big issue. It becomes a problem if you fetch the token once at startup and reuse it for hours.

## 2. Retries

Azure sometimes returns:

- **429** — too many requests (throttled)
- **5xx** — temporary server error

The SDK waits and retries those automatically (often using `Retry-After`).

With axios, a 429 fails immediately unless you add retry logic. For a once-a-day sync this is usually fine. For frequent polling, retries matter.

## 3. `$skipToken` (the 1000-device limit)

Resource Graph returns at most **1000 rows per call**.

If you have 2500 devices:

| Call | What you get |
|------|----------------|
| 1 | devices 1–1000, plus a skipToken |
| 2 | devices 1001–2000, plus a new skipToken |
| 3 | devices 2001–2500, no skipToken |

`$skipToken` is Azure’s “here is the next page” bookmark. You send it back in the next request.

Our current SDK code does that loop:

```js
do {
  const response = await client.resources({ ..., skipToken });
  rows.push(...response.data);
  skipToken = response.skipToken;
} while (skipToken);
```

A single axios POST with no loop only ever returns the first 1000 devices. The rest are silently missing.

If you have fewer than 1000 devices, one call is enough and you never see `$skipToken`.

## Short version

| Piece | Meaning | Need it? |
|-------|---------|----------|
| Token refresh | Get a new Azure token when the old one expires | Only if you cache the token |
| Retries | Try again on 429/5xx | Nice to have; not required for a simple sync |
| `$skipToken` | Fetch page 2, 3, … after 1000 rows | Required if you can have more than 1000 devices |
