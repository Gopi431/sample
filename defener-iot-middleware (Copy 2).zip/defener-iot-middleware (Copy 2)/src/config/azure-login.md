# How Azure Login Works

There is no Defender-specific token in our code. We log in as an **app registration** (service principal), then Resource Graph returns Defender for IoT device rows from that subscription.

## Who you log in as

An app registration (service principal) in your tenant:

| Env var | Meaning |
|---------|---------|
| `AZURE_TENANT_ID` | Which Entra directory |
| `AZURE_CLIENT_ID` | Which app |
| `AZURE_CLIENT_SECRET` | That app’s password |

Someone in Azure also gives that app **Reader** (or similar) on the subscription that has Defender for IoT.

That is the login identity.

## How our code logs in

```js
new ResourceGraphClient(new DefaultAzureCredential())
```

`DefaultAzureCredential` does this:

1. Reads `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET` from the environment.
2. Calls Entra ID: “give me a token for `https://management.azure.com/.default`.”
3. Gets a Bearer token.

Every Resource Graph call sends `Authorization: Bearer <that token>`.

You never type a token. The SDK does the login.

## How that reaches Defender for IoT

Defender for IoT (cloud-connected sensors) publishes inventory into Azure. It is **not** a second login.

Then we call:

```http
POST https://management.azure.com/providers/Microsoft.ResourceGraph/resources
```

with:

- **token** from the step above (proves who you are)
- **subscriptions:** `[AZURE_SUBSCRIPTION_ID]` (which subscription to search)
- **KQL:** `iotsecurityresources | where type == '...devices'` (which Defender data)

Azure checks: this app can read this subscription → Resource Graph returns device rows from Defender for IoT.

## Flow

```
Env vars (tenant, client, secret)
        ↓
DefaultAzureCredential  →  Entra ID token
        ↓
ResourceGraphClient     →  management.azure.com
        ↓
iotsecurityresources (Defender for IoT devices)
```
