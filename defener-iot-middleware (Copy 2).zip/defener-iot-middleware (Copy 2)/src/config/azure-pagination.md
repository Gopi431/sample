# Resource Graph Pagination (`$skipToken`)

Pagination is handled in `fetchDevices` with Azure’s `$skipToken`, not with page numbers like `page=1`, `page=2`.

## The rule

Resource Graph returns at most **1000 devices per request** (`top` / `$top`). We use `config.resourceGraph.pageSize`, capped at 1000.

If there are more devices, the response includes `skipToken`. You send that token on the next request to get the next chunk. When `skipToken` is empty, you are done.

## What our code does

```js
do {
  const response = await client.resources({
    subscriptions: [config.azure.subscriptionId],
    query: DEVICES_QUERY,
    options: { resultFormat: "objectArray", top: config.resourceGraph.pageSize, skipToken },
  });
  rows.push(...response.data);
  skipToken = response.skipToken;
} while (skipToken);
```

### Flow

1. **First call:** `skipToken` is `undefined` → Azure returns devices 1–1000 (or fewer if that is all).
2. Append `response.data` into `rows`.
3. If Azure sends `response.skipToken`, loop again and pass it in `options.skipToken`.
4. Repeat until `skipToken` is missing/empty.
5. Return the full `rows` array (all pages merged).

## Example with 2500 devices

| Call | skipToken sent | Devices in this response | skipToken returned |
|------|----------------|--------------------------|--------------------|
| 1 | none | 1–1000 | token A |
| 2 | token A | 1001–2000 | token B |
| 3 | token B | 2001–2500 | none → loop stops |

The query has `| order by id asc` so page order stays stable across those calls.
