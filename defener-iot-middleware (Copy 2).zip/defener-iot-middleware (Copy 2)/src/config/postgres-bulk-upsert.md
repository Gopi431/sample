# Saving thousands of devices into Postgres

Postgres can store far more than thousands of devices. The question is **how this app writes them**, not whether the database has space.

## How a sync writes data

1. Azure pages (1000 per call) are collected in Node memory until the list is complete.
2. Rows are mapped.
3. Then they are written to Postgres — **one upsert after a successful full fetch**. Nothing is inserted page-by-page from Azure.

```13:18:src/repositories/deviceRepository.js
  async upsertDevices(devices) {
    ...
      const rows = await DeviceModel.bulkCreate(devices, { updateOnDuplicate: UPDATE_ON_CONFLICT });
```

That becomes SQL like:

```sql
INSERT INTO devices (external_id, device_name, ...)
VALUES (...), (...), ...   -- many rows
ON CONFLICT (external_id) DO UPDATE SET ...
```

- New `external_id` → insert
- Existing `external_id` → update (same device, no duplicate row)

Postgres is built for this. Tens of thousands of rows in `devices` is normal.

## “Capacity” — two different limits

| Limit | Meaning |
|-------|---------|
| **Table size** | Azure PostgreSQL can hold millions of rows. Thousands of devices is not a storage problem. |
| **One SQL statement** | Postgres allows about 65,535 parameters per query. Each device uses many columns (~16–18), so one `bulkCreate` of all rows can break around ~3,000–4,000 devices. |

So: the database can hold the data; a **single giant INSERT** might not.

## What the current code does

- **Typical OT size** (hundreds to a couple of thousand): one `bulkCreate` is usually fine.
- **Many thousands** (5k, 20k, …): we do not split into chunks of 500/1000 in the current Sequelize repository (the earlier raw-pg version did batches of 500). That is a gap if inventory grows large.
- **Memory:** the whole list sits in Node until upsert finishes. For ~10k devices that is still small; for hundreds of thousands you would stream/page into the DB.

## If Azure fails mid-fetch

No partial insert. Last successful sync stays in the table. Next successful sync upserts the full list again.

## Summary

Postgres can insert thousands of devices. We save them with **one bulk upsert keyed on `external_id`**. Table capacity is not the issue; **statement size / batching** is the thing to watch if you go well beyond a few thousand rows in one sync. We can add `bulkCreate` in loops of 500 if you want that safety.
