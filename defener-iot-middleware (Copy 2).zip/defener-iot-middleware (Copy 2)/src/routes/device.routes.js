const express = require("express");
const router = express.Router();
const deviceController = require("../controllers/device.controller");
// const { verifyToken } = require("../middlewares/authMiddleware"); // enable when auth is introduced

/**
 * @access Public (auth to be added in a later phase)
 */
router.post("/sync-devices", deviceController.syncDevices);
router.get("/get-devices", deviceController.getDevices);
router.get("/get-hierarchy", deviceController.getHierarchy);
router.get("/get-trends", deviceController.getTrends);

module.exports = router;
