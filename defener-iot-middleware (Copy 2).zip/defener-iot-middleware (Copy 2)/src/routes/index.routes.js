const express = require("express");
const router = express.Router();
const deviceRoutes = require("./device.routes");

router.use("/device", deviceRoutes);

module.exports = router;
