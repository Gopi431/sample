const express = require("express");
const routes = require("./routes/routes");
const LoggerCustomUtils = require("./utils/loggerCustoms");
const logger = new LoggerCustomUtils("app");

const app = express();

app.use(express.json());
app.use("/api", routes);

app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
});

// Any unexpected error in a route ends up here.
app.use((error, req, res, next) => {
  logger.error("errorHandler", `${req.method} ${req.originalUrl} failed: ${error.message}`, error);
  res.status(500).json({ error: error.message || "Internal server error" });
});

module.exports = app;
