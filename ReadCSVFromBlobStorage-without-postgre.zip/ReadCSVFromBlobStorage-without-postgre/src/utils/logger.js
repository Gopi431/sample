const { createLogger, format, transports } = require("winston");
require("winston-daily-rotate-file");

// "2026-10-21 17:20:05 info [BlobInventoryService:readDeviceInventory]: Read d4iot_20261021_100034.csv ..."
const line = format.printf((info) => {
  return `${info.timestamp} ${info.level} [${info.fileName || "unknown"}:${info.methodName || "unknown"}]: ${info.message}`;
});

// Hourly log files in logs/, kept for 5 days.
const fileOptions = {
  datePattern: "YYYY-MM-DD-HH",
  zippedArchive: true,
  maxSize: "20m",
  maxFiles: "5d",
  format: line,
};

const logger = createLogger({
  level: "debug",
  format: format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  transports: [
    new transports.Console({ format: format.combine(format.colorize(), line) }),
    new transports.DailyRotateFile({ ...fileOptions, filename: "logs/defender-iot-blob-%DATE%.log" }),
    new transports.DailyRotateFile({ ...fileOptions, filename: "logs/defender-iot-blob-%DATE%-Error.log", level: "error" }),
  ],
});

module.exports = logger;
