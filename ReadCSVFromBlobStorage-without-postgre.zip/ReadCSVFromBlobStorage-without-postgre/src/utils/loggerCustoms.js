const logger = require("./logger");

/**
 * Small wrapper around the winston logger that tags every entry with the
 * owning file/class name and the method name.
 */
function LoggerCustom(name) {
  this.fileName = name;
}

LoggerCustom.prototype.info = function info(methodName, message, data) {
  logger.info(message, { fileName: this.fileName, methodName, data });
};

LoggerCustom.prototype.warn = function warn(methodName, message, data) {
  logger.warn(message, { fileName: this.fileName, methodName, data });
};

LoggerCustom.prototype.error = function error(methodName, message, err) {
  logger.error(err?.stack ? `${message}\n${err.stack}` : message, { fileName: this.fileName, methodName });
};

module.exports = LoggerCustom;
