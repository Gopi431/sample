const express = require("express");
const { readDeviceInventory } = require("../services/blobInventoryService");

const router = express.Router();

/**
 * GET /api/devices
 * GET /api/devices?blobName=d4iot_20261021_100034.csv
 * Reads the device inventory CSV from Blob Storage (the latest one when blobName is not given).
 *   200 - devices read
 *   502 - could not list / download / parse the blob
 */
router.get("/devices", async (req, res) => {
  const result = await readDeviceInventory(req.query.blobName);
  const statusCode = { completed: 200, failed: 502 }[result.status];
  res.status(statusCode).json(result);
});

module.exports = router;
