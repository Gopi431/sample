const path = require("path");
const dotenv = require("dotenv");

// Load env first: the storage account and container are read from process.env.
dotenv.config({
  path: path.resolve(__dirname, `./src/config/${process.env.NODE_ENV || "development"}.env`),
  quiet: true,
});

const app = require("./src/app");
const LoggerCustomUtils = require("./src/utils/loggerCustoms");
const logger = new LoggerCustomUtils("index");

const PORT = parseInt(process.env.PORT || "3000", 10);

async function start() {
  app.listen(PORT, () => {
    logger.info("start", `API listening on http://localhost:${PORT}/api`);
  });
}

start().catch((error) => {
  logger.error("start", `Failed to start: ${error.message}`, error);
  process.exit(1);
});
